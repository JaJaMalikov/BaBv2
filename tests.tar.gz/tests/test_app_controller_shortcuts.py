"""Protocol-fake based tests for AppController shortcut methods (copy/paste).

Headless-friendly and Qt-free: fakes implement only the attributes needed
by AppController via the Protocols declared in ui/contracts.py.
"""

from __future__ import annotations

from typing import Any

from controllers.app_controller import AppController
from core.scene_model import SceneModel, Keyframe


class _FakePlayback:
    def __init__(self) -> None:
        self.copied: dict[int, Keyframe] = {}
        self.pasted: list[tuple[int, int]] = []

    def copy_keyframe(self, index: int) -> None:
        # record copy request
        self.copied[index] = Keyframe(index)

    def paste_keyframe(self, index: int) -> None:
        # record paste request
        self.pasted.append((index, index))


class _FakeDock:
    def show(self) -> None:  # pragma: no cover - not used in this test
        pass

    class _Sig:
        def connect(self, _):  # pragma: no cover - not used in this test
            pass

    visibilityChanged = _Sig()
    topLevelChanged = _Sig()


class _FakeScene:
    def __init__(self) -> None:
        self._sel_changed_cb = None

    class _Sig:
        def __init__(self, owner: _FakeScene) -> None:
            self._owner = owner

        def connect(self, cb):  # pragma: no cover - not used in this test
            self._owner._sel_changed_cb = cb

    @property
    def selectionChanged(self) -> Any:
        return self._Sig(self)


class _FakeShortcut:
    def __init__(self) -> None:
        self.activated = _FakeSignal()


class _FakeSignal:
    def __init__(self) -> None:
        self._cbs: list[Any] = []

    def connect(self, cb) -> None:
        self._cbs.append(cb)

    def emit(self) -> None:
        for cb in list(self._cbs):
            cb()


class _FakeTimeline:
    def __init__(self) -> None:
        self._kfs: set[int] = set()

    def add_keyframe_marker(self, idx: int) -> None:
        self._kfs.add(int(idx))


class _FakeWin:
    def __init__(self) -> None:
        self.scene_model = SceneModel()
        self.timeline_dock = _FakeDock()
        self.timeline_widget = _FakeTimeline()
        self.playback_handler = _FakePlayback()
        self.scene = _FakeScene()
        self._kf_copy_sc = _FakeShortcut()
        self._kf_paste_sc = _FakeShortcut()

    # Methods referenced by AppController.startup_sequence
    def showMaximized(self) -> None:  # pragma: no cover - not used here
        pass

    def ensure_fit(self) -> None:  # pragma: no cover - not used here
        pass

    def update_onion_skins(self) -> None:  # pragma: no cover - not used here
        pass


def test_copy_and_paste_shortcuts_route_to_playback() -> None:
    win = _FakeWin()
    AppController(win)

    # Create a keyframe and mark it on the fake timeline
    idx = 3
    win.scene_model.add_keyframe(idx, {"objects": {}, "puppets": {}})
    win.timeline_widget.add_keyframe_marker(idx)
    win.scene_model.go_to_frame(idx)

    # Simulate shortcut activation
    win._kf_copy_sc.activated.emit()
    win._kf_paste_sc.activated.emit()

    assert idx in win.playback_handler.copied
    assert (idx, idx) in win.playback_handler.pasted
