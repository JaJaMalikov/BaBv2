import ast
from pathlib import Path

FORBIDDEN_PREFIXES = ("PySide", "PyQt", "Qt")
CORE_DIR = Path(__file__).resolve().parents[1] / "core"


def _offending_imports_in_file(py_file: Path) -> list[str]:
    offenders: list[str] = []
    try:
        tree = ast.parse(py_file.read_text(encoding="utf-8"), filename=str(py_file))
    except SyntaxError as e:
        # If a file has a syntax error, surface it via the test failure context
        offenders.append(f"SYNTAX ERROR in {py_file}: {e}")
        return offenders

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                name = alias.name.split(".")[0]
                if name.startswith(FORBIDDEN_PREFIXES):
                    offenders.append(f"import {alias.name} in {py_file}")
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                root = node.module.split(".")[0]
                if root.startswith(FORBIDDEN_PREFIXES):
                    offenders.append(f"from {node.module} import ... in {py_file}")
    return offenders


def test_core_has_no_qt_imports():
    assert CORE_DIR.is_dir(), f"Expected core/ directory at {CORE_DIR}"
    offending: list[str] = []
    for py in CORE_DIR.rglob("*.py"):
        offending.extend(_offending_imports_in_file(py))
    assert not offending, "Qt/PySide imports detected in core/:\n" + "\n".join(
        offending
    )
