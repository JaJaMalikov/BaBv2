from __future__ import annotations

import pytest
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QSettings

from ui.main_window import MainWindow
from ui.settings_manager import SettingsManager
from ui.settings_keys import (
    GEOMETRY_MAINWINDOW,
    GEOMETRY_LIBRARY,
    GEOMETRY_INSPECTOR,
    GEOMETRY_VIEW_TOOLBAR,
    GEOMETRY_MAIN_TOOLBAR,
)


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


def test_geometry_load_raises_overlays_and_marks_loaded(
    app, monkeypatch
):  # noqa: ARG001
    # Arrange a fresh MainWindow and isolate QSettings scope
    win = MainWindow()
    org = "JaJa_TEST_geom"
    app_name = "Macronotron_TEST_geom"

    # Seed geometry keys so settings_geometry.load() finds them
    s = QSettings(org, app_name)
    s.clear()
    try:
        s.setValue(GEOMETRY_MAINWINDOW, win.saveGeometry())
        s.setValue(GEOMETRY_LIBRARY, win.library_overlay.geometry())
        s.setValue(GEOMETRY_INSPECTOR, win.inspector_overlay.geometry())
        if getattr(win.view, "_overlay", None):
            s.setValue(GEOMETRY_VIEW_TOOLBAR, win.view._overlay.geometry())
        if getattr(win.view, "_main_tools_overlay", None):
            s.setValue(GEOMETRY_MAIN_TOOLBAR, win.view._main_tools_overlay.geometry())

        called = {"lib": False, "insp": False, "view": False, "main": False}

        # Monkeypatch raise_ methods to track invocation without relying on QWidget internals
        lib_overlay = win.library_overlay
        insp_overlay = win.inspector_overlay
        view_overlay = getattr(win.view, "_overlay", None)
        main_tools_overlay = getattr(win.view, "_main_tools_overlay", None)

        def _mk_flag(name):
            def _flag():
                called[name] = True

            return _flag

        monkeypatch.setattr(lib_overlay, "raise_", _mk_flag("lib"), raising=False)
        monkeypatch.setattr(insp_overlay, "raise_", _mk_flag("insp"), raising=False)
        if view_overlay:
            monkeypatch.setattr(view_overlay, "raise_", _mk_flag("view"), raising=False)
        if main_tools_overlay:
            monkeypatch.setattr(
                main_tools_overlay, "raise_", _mk_flag("main"), raising=False
            )

        # Act
        sm = SettingsManager(win, org=org, app=app_name)
        sm.load()

        # Assert overlays were raised and settings flag set
        assert called["lib"] is True
        assert called["insp"] is True
        assert win._settings_loaded is True

    finally:
        s.clear()
