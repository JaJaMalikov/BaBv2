"""Tests for scene model serialization and deserialization."""

import json

from core.scene_model import SceneModel, SceneObject


def test_scene_object_roundtrip():
    """Test that a SceneObject can be serialized and deserialized."""
    obj = SceneObject("rock", "image", "rock.png", x=1, y=2, rotation=3, scale=0.5)
    obj.attach("p", "arm")
    data = obj.to_dict()
    cloned = SceneObject.from_dict(data)
    assert cloned.name == "rock"
    assert cloned.obj_type == "image"
    assert cloned.file_path == "rock.png"
    assert cloned.x == 1
    assert cloned.y == 2
    assert cloned.rotation == 3
    assert cloned.scale == 0.5
    assert cloned.attached_to == ("p", "arm")


def test_scene_export_import_roundtrip(tmp_path):
    """Roundtrip a scene via JSON file using pure model to_dict/from_dict."""
    scene = SceneModel()
    obj = SceneObject("tree", "image", "tree.png", x=10, y=20, rotation=5, scale=1.5)
    scene.add_object(obj)
    scene.add_keyframe(0)
    file_path = tmp_path / "scene.json"

    # Export
    with file_path.open("w", encoding="utf-8") as f:
        json.dump(scene.to_dict(), f, indent=2)

    # Import
    scene2 = SceneModel()
    data = json.loads(file_path.read_text(encoding="utf-8"))
    scene2.from_dict(data)

    assert "tree" in scene2.objects
    loaded = scene2.objects["tree"]
    assert loaded.x == 10
    assert loaded.y == 20
    assert loaded.rotation == 5
    assert loaded.scale == 1.5
    assert loaded.file_path == "tree.png"


def test_from_dict_ignores_keyframe_without_index():
    """from_dict should ignore keyframe entries missing an index."""
    from core.scene_model import SceneModel

    scene = SceneModel()
    data = {
        "settings": {
            "start_frame": 0,
            "end_frame": 10,
            "fps": 24,
            "scene_width": 1920,
            "scene_height": 1080,
        },
        "objects": {},
        "keyframes": [
            {"objects": {"foo": {"x": 1}}},  # missing index, should be ignored
            {"index": 3, "objects": {}, "puppets": {}},
        ],
    }
    scene.from_dict(data)
    assert list(scene.keyframes.keys()) == [3]


essential_min = 1


def test_scene_model_settings_roundtrip_boundaries():
    """Boundary values for settings should round-trip via to_dict/from_dict."""
    from core.scene_model import SceneModel

    scene = SceneModel()
    scene.start_frame = 0
    scene.end_frame = 1
    scene.fps = 1
    scene.scene_width = 1
    scene.scene_height = 1

    data = scene.to_dict()
    clone = SceneModel()
    clone.from_dict(data)

    assert clone.start_frame == 0
    assert clone.end_frame == 1
    assert clone.fps == 1
    assert clone.scene_width == 1
    assert clone.scene_height == 1
