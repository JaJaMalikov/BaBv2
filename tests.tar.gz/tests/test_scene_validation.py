"""Tests for scene validation helpers."""

import logging

from core.scene_validation import (
    validate_settings,
    validate_objects,
    validate_keyframes,
)


def test_validate_settings_basic_and_strict(caplog):
    """Settings must be dict with integer values and valid ranges."""
    assert (
        validate_settings({"fps": 24, "scene_width": 800, "scene_height": 600}) is True
    )
    assert validate_settings(None) is True
    with caplog.at_level(logging.ERROR):
        # Wrong container type
        assert validate_settings([1, 2, 3]) is False
        assert "expected dict" in caplog.text
    with caplog.at_level(logging.ERROR):
        # Type errors
        assert validate_settings({"fps": "24"}) is False
        assert "fps" in caplog.text
    with caplog.at_level(logging.ERROR):
        # Semantic constraints
        assert validate_settings({"fps": 0}) is False
        assert "fps must be > 0" in caplog.text
    with caplog.at_level(logging.ERROR):
        assert validate_settings({"scene_width": 0}) is False
        assert "scene_width" in caplog.text
    with caplog.at_level(logging.ERROR):
        assert validate_settings({"scene_height": -1}) is False
        assert "scene_height" in caplog.text
    with caplog.at_level(logging.ERROR):
        assert validate_settings({"start_frame": 10, "end_frame": 5}) is False
        assert "start_frame" in caplog.text


def test_validate_objects_strict(caplog):
    """Objects must map names (str) to dicts; None is ok."""
    assert validate_objects({"tree": {}}) is True
    assert validate_objects({}) is True
    assert validate_objects(None) is True
    with caplog.at_level(logging.ERROR):
        assert validate_objects({"tree": []}) is False
        assert "invalid entry" in caplog.text
    with caplog.at_level(logging.ERROR):
        assert validate_objects(42) is False
        assert "expected dict" in caplog.text
    with caplog.at_level(logging.ERROR):
        # Non-string key should fail
        assert validate_objects({1: {}}) is False
        assert "invalid entry" in caplog.text


def test_validate_keyframes_edges(caplog):
    """Keyframes must be list[dict]; index is optional int and unique when present."""
    assert validate_keyframes(None) is True
    assert validate_keyframes([{}]) is True  # missing index is acceptable
    assert validate_keyframes([{"index": 1}, {}]) is True
    with caplog.at_level(logging.ERROR):
        assert validate_keyframes("not a list") is False
        assert "expected list" in caplog.text
    with caplog.at_level(logging.ERROR):
        assert validate_keyframes([1, 2]) is False
        assert "each item must be dict" in caplog.text
    with caplog.at_level(logging.ERROR):
        assert validate_keyframes([{"index": "a"}]) is False
        assert "'index' must be int" in caplog.text
    with caplog.at_level(logging.ERROR):
        assert validate_keyframes([{"index": 2}, {"index": 2}]) is False
        assert "duplicate index" in caplog.text
