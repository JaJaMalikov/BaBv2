from __future__ import annotations

import pytest
from PySide6.QtCore import QSettings

from ui.settings_manager import SettingsManager
from ui import settings_geometry
from ui.settings_keys import (
    GEOMETRY_MAINWINDOW,
    GEOMETRY_LIBRARY,
    GEOMETRY_INSPECTOR,
    GEOMETRY_VIEW_TOOLBAR,
    GEOMETRY_MAIN_TOOLBAR,
    LAYOUT_TIMELINE_VISIBLE,
    UI_THEME,
    UI_ICON_DIR,
    TIMELINE_BG,
)


@pytest.fixture()
def test_scope():
    # Use a dedicated org/app so we don't pollute real settings
    org = "JaJa_TEST"
    app = "Macronotron_TEST"
    # Ensure a clean slate
    s = QSettings(org, app)
    s.clear()
    yield org, app
    s.clear()


def _populate_all_keys(org: str, app: str) -> None:
    s = QSettings(org, app)
    # Geometry/layout keys
    s.setValue(GEOMETRY_MAINWINDOW, b"bytes-geometrie")
    s.setValue(GEOMETRY_LIBRARY, "0,0,100,100")
    s.setValue(GEOMETRY_INSPECTOR, "10,10,120,120")
    s.setValue(GEOMETRY_VIEW_TOOLBAR, "20,20,50,50")
    s.setValue(GEOMETRY_MAIN_TOOLBAR, "30,30,60,60")
    s.setValue(LAYOUT_TIMELINE_VISIBLE, True)
    # Non-geometry keys
    s.setValue(UI_THEME, "dark")
    s.setValue(UI_ICON_DIR, "/tmp/icons")
    s.setValue(TIMELINE_BG, "#112233")


def test_settings_geometry_clear_only_removes_layout_and_geometry(test_scope):
    org, app = test_scope
    _populate_all_keys(org, app)

    # Act: clear only geometry/layout
    settings_geometry.clear(org, app)

    s = QSettings(org, app)
    # Geometry/layout should be removed
    assert not s.contains(GEOMETRY_MAINWINDOW)
    assert not s.contains(GEOMETRY_LIBRARY)
    assert not s.contains(GEOMETRY_INSPECTOR)
    assert not s.contains(GEOMETRY_VIEW_TOOLBAR)
    assert not s.contains(GEOMETRY_MAIN_TOOLBAR)
    assert not s.contains(LAYOUT_TIMELINE_VISIBLE)

    # Other keys must remain intact
    assert s.value(UI_THEME) == "dark"
    assert s.value(UI_ICON_DIR) == "/tmp/icons"
    assert s.value(TIMELINE_BG) == "#112233"


def test_settings_manager_clear_delegates_to_settings_geometry(monkeypatch, test_scope):
    org, app = test_scope
    called = {"ok": False, "args": None}

    def _fake_clear(_org: str, _app: str) -> None:  # noqa: ARG001
        called["ok"] = True
        called["args"] = (_org, _app)

    # Arrange: fake clear and call SettingsManager.clear()
    monkeypatch.setattr(settings_geometry, "clear", _fake_clear)

    class _DummyWin:
        pass

    sm = SettingsManager(_DummyWin(), org=org, app=app)
    sm.clear()

    assert called["ok"] is True
    assert called["args"] == (org, app)
