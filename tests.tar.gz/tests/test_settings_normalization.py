import pytest

from ui.ui_profile import _bool, _int, _float, _color


class TestBoolNormalization:
    def test_true_values(self):
        assert _bool(True) is True
        assert _bool("true") is True
        assert _bool("True") is True
        assert _bool(" TRUE ") is True
        assert _bool("1") is True
        assert _bool("yes") is True
        assert _bool("on") is True

    def test_false_values(self):
        assert _bool(False) is False
        assert _bool("false") is False
        assert _bool("False") is False
        assert _bool("0") is False
        assert _bool("no") is False
        assert _bool("off") is False

    def test_none_uses_default(self):
        assert _bool(None) is False
        assert _bool(None, True) is True

    def test_unknown_string_falls_back_false(self):
        # Current implementation returns False for unknown non-empty strings,
        # regardless of the default (default is only applied to None).
        assert _bool("maybe", True) is False
        assert _bool("", True) is False


class TestIntNormalization:
    def test_int_and_numeric_strings(self):
        assert _int(5) == 5
        assert _int("5") == 5
        assert _int(" 42 ") == 42
        assert _int("-7") == -7

    def test_floaty_strings_are_truncated(self):
        # Implementation uses int(float(s)) when not purely digits
        assert _int("3.7") == 3
        assert _int("-2.1") == -2

    def test_invalid_int_returns_default(self):
        assert _int("abc") == 0
        assert _int("abc", default=9) == 9
        assert _int(None, default=11) == 11


class TestFloatNormalization:
    def test_float_and_numeric_strings(self):
        assert _float(3.5) == pytest.approx(3.5)
        assert _float(2) == pytest.approx(2.0)
        assert _float("4.25") == pytest.approx(4.25)

    def test_comma_decimal(self):
        assert _float("3,5") == pytest.approx(3.5)

    def test_invalid_float_returns_default(self):
        assert _float("abc") == 0.0
        assert _float("abc", default=1.25) == pytest.approx(1.25)
        assert _float(None, default=2.5) == pytest.approx(2.5)


class TestColorNormalization:
    def test_hex_colors(self):
        assert _color("#000000") == "#000000"
        assert _color("#ffffff") == "#ffffff"
        assert _color("#A1B2C3") == "#A1B2C3"
        assert _color("#A1B2C3FF") == "#A1B2C3FF"

    def test_invalid_colors(self):
        assert _color("#GGGGGG") == "#000000"
        assert _color("#12345") == "#000000"
        assert _color("") == "#000000"
        assert _color(None) == "#000000"

    def test_rgba_passthrough(self):
        assert _color("rgba(255,0,0,0.5)") == "rgba(255,0,0,0.5)"
        assert _color("RGBA(0,0,0,1)") == "RGBA(0,0,0,1)"
