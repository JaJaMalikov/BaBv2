"""Tests for the timeline view via the Protocol-compatible adapter."""

import pytest
from PySide6.QtWidgets import QApplication

from ui.timeline_view_adapter import TimelineViewAdapter


@pytest.fixture(scope="module")
def app():
    """Create a QApplication instance for the tests."""
    qapp = QApplication.instance()
    if qapp is None:
        qapp = QApplication([])
    return qapp


def test_add_keyframe_marker_and_navigation(_app):
    """Test that keyframe markers can be added and navigated via adapter."""
    tw = TimelineViewAdapter()
    tw.add_keyframe_marker(5)
    tw.add_keyframe_marker(10)
    assert tw.has_keyframe(5) and tw.has_keyframe(10)

    tw.set_current_frame(7)
    tw.prev_keyframe()
    assert tw.get_current_frame() == 5
    tw.next_keyframe()
    assert tw.get_current_frame() == 10
    tw.next_keyframe()
    assert tw.get_current_frame() == 5


def test_zoom_with_wheel_event(_app):
    """Test that the timeline can be zoomed with the wheel event via adapter."""
    tw = TimelineViewAdapter()
    tw.resize(400, 100)
    initial = tw.get_pixels_per_frame()
    tw.wheel_zoom(120)
    zoomed = tw.get_pixels_per_frame()
    assert zoomed > initial
    tw.wheel_zoom(-120)
    assert tw.get_pixels_per_frame() < zoomed
